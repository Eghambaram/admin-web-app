import React from 'react';
import { useTheme } from '@mui/material/styles';
import Box from '@mui/material/Box';
import CssBaseline from '@mui/material/CssBaseline';
import AppBarComponent from './AppBarComponent';
import DrawerComponent from './DrawerComponent';
import { Outlet } from 'react-router-dom';

function AdminLayout() {
  const theme = useTheme();
  const [open, setOpen] = React.useState(false);

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };

  return (
    <Box sx={{ display: 'flex',minHeight: '100vh' }}>
      <CssBaseline />
      <AppBarComponent open={open} handleDrawerOpen={handleDrawerOpen} />
      <DrawerComponent open={open} handleDrawerClose={handleDrawerClose} />
      <Box component="main" sx={{
                  flexGrow: 1,
                  p: 3,
                  overflow: 'auto',
                  backgroundColor: '#ede7f6', // Custom background color
                }}>
        <div style={{ ...theme.mixins.toolbar }} />
        <Outlet />
      </Box>
    </Box>
  );
}

export default AdminLayout;
