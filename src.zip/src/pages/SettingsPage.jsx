// src/pages/SettingsPage.js
import React from 'react';
import { Typography, Box } from '@mui/material';

const SettingsPage = () => {
  return (
    <Box>
      <Typography variant="h4">Settings</Typography>
      <Typography>Manage your settings here.</Typography>
    </Box>
  );
};

export default SettingsPage;
