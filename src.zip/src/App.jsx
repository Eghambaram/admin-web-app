// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route, RouterProvider, createBrowserRouter, Navigate } from 'react-router-dom';
import AdminLayout from './components/AdminLayout';
import DashboardPage from './pages/DashboardPage';
import SettingsPage from './pages/SettingsPage';
import SigninPage from './pages/SigninPage';


// Mock function to get the current user's role
const getCurrentUserRole = () => {
  // This should be replaced with actual logic to get the current user's role
  return 'user'; // Example roles: 'admin', 'vendor', 'user', 'superadmin'
};

// Higher-order component for role-based route protection
const ProtectedRoute = ({ element, allowedRoles }) => {
  const userRole = getCurrentUserRole();
  return allowedRoles.includes(userRole) ? element : <Navigate to="/login" />;
};

const router = createBrowserRouter([
  {
    path: "/",
    element: <AdminLayout />,
    children: [
      {
        path: "/",
        element: <DashboardPage />,
      },
      {
        path: "/settings",
        element: (
          <ProtectedRoute
            element={<SettingsPage />}
            allowedRoles={['admin', 'superadmin']}
          />
        ),
      },
      // {
      //   path: "/products",
      //   element: (
      //     <ProtectedRoute
      //       element={<Products />}
      //       allowedRoles={['admin', 'vendor', 'superadmin']}
      //     />
      //   ),
      // },
      // {
      //   path: "/users/:id",
      //   element: (
      //     <ProtectedRoute
      //       element={<User />}
      //       allowedRoles={['admin', 'superadmin']}
      //     />
      //   ),
      // },
      // {
      //   path: "/products/:id",
      //   element: (
      //     <ProtectedRoute
      //       element={<Product />}
      //       allowedRoles={['admin', 'vendor', 'superadmin']}
      //     />
      //   ),
      // },
    ],
  },
  {
    path: "/signin",
    element: <SigninPage />,
  },
]);

export default function App() {
  return <RouterProvider router={router} />;
}




// // src/App.js
// import React from 'react';
// import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
// import AdminLayout from './components/AdminLayout';
// import DashboardPage from './pages/DashboardPage';
// import SettingsPage from './pages/SettingsPage';
// import SigninPage from './pages/SigninPage';

// const App = () => {
  
//   return (
//     <Router>
//       <Routes>
//         <Route path="/" element={<AdminLayout />}>
//           <Route index element={<DashboardPage />} />
//           <Route path="settings" element={<SettingsPage />} />
//         </Route>
//         <Route path="/signin" element={<SigninPage />} />
//       </Routes>
//     </Router>
//   );
// };

// export default App;
